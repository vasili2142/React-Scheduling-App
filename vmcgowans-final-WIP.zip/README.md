# Planning

- This application will be a calendar that stores information on any selected month and day, and allows them to retrieve that same inforamation for later.

- There will be at least 3 pages: 
  # Admin page
    Here the administrator can interact with user accounts
  # User Page
    Here the user can see information about what they've entered into the calendar
  # Calendar/Form page
    Display the calendar

# Possible Risks

- The application is meant to be a booking system where the user creates a task that gets sent to the admin for approval. The admin either accepts, or rejects the request. Handling requests is not something familiar to me.

- Application might not have full admin implementation to handle requests as this is something I've never done

- This project is also 1 of 3 finals that I need to complete. Managing time will be key to making worthwile progress.

## Technologies Used

## SASS
## Firebase
## React
## React Router

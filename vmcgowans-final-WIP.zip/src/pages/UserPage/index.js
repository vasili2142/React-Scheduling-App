import { auth } from "../../database/config";
import PageContainer from "../../components/PageContainer";
import { useEffect, useState } from "react";
import * as database from "../../database";
import { useNavigate } from "react-router-dom";

export default function UserPage() {
  const [currentUser, setCurrentUser] = useState([]);

  useEffect(() => {
    auth.onAuthStateChanged((user) => {
      if (user) {
        setCurrentUser(user);
      }      
      console.log(auth.currentUser);
    });
  }, []);

  const navigate = useNavigate();

  /**
   * Handles the sign-out process.
   * Prevents the default form submission behavior and signs out the current user
   * using the `userSignOut` method from the database module.
   *
   * @param {Event} e - The event object from the sign-out button click.
   */
  const handleSignOut = (e) => {
    // e.preventDefault();
    database.userSignOut(auth.currentUser.email);
    navigate("/login");
  };

  return (
    <>
      {auth.currentUser && (
        <PageContainer
          title={
            currentUser.displayName ? currentUser.displayName : "somthing wrong"
          }
        >
          <p>This is where users are redirected to on login</p>
          <button onClick={handleSignOut}>Sign Out</button>
        </PageContainer>
      )}
      {auth.currentUser === null && (
        <PageContainer>
          <div>Not Logged In</div>
        </PageContainer>
      )}
    </>
  );
}

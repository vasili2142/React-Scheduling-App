export default function Loading() {
  return <div className="loading-component">Loading...</div>;
}

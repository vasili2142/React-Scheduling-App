export default function UserMainPage() {
  return(
    <>
      <p>
        This is the main user page
      </p>
    </>
  );
}
